package com.example.signup_sqlite;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class UserAdapter extends RecyclerView.Adapter<UserAdapter.ViewHolder> {
    private Context context;
    private List<User> userList;
    private DatabaseHelper dbHelper;

    public UserAdapter(Context context, List<User> userList) {
        this.context = context;
        this.userList = userList;
        this.dbHelper = new DatabaseHelper(context);
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.activity_useritem, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        User user = userList.get(position);
        holder.nameText.setText(user.getFirstName() + " " + user.getLastName());
        holder.emailText.setText(user.getEmail());

        // Set existing values in edit fields
        holder.editFirstName.setText(user.getFirstName());
        holder.editLastName.setText(user.getLastName());
        holder.editEmail.setText(user.getEmail());

        // Edit Button Click (Show Edit Layout)
        holder.editButton.setOnClickListener(v -> {
            if (holder.editLayout.getVisibility() == View.GONE) {
                holder.editLayout.setVisibility(View.VISIBLE);
            } else {
                holder.editLayout.setVisibility(View.GONE);
            }
        });

        // Update Button Click (Save Changes)
        holder.updateButton.setOnClickListener(v -> {
            String updatedFirstName = holder.editFirstName.getText().toString().trim();
            String updatedLastName = holder.editLastName.getText().toString().trim();
            String updatedEmail = holder.editEmail.getText().toString().trim();

            if (!updatedFirstName.isEmpty() && !updatedLastName.isEmpty() && !updatedEmail.isEmpty()) {
                boolean updated = dbHelper.updateUser(user.getId(), updatedFirstName, updatedLastName, updatedEmail);
                if (updated) {
                    user.setFirstName(updatedFirstName);
                    user.setLastName(updatedLastName);
                    user.setEmail(updatedEmail);
                    notifyItemChanged(position);
                    holder.editLayout.setVisibility(View.GONE);
                    Toast.makeText(context, "User updated", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(context, "Update failed", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(context, "Fields cannot be empty", Toast.LENGTH_SHORT).show();
            }
        });

        // Cancel Button Click (Hide Edit Layout)
        holder.cancelButton.setOnClickListener(v -> holder.editLayout.setVisibility(View.GONE));

        // Delete Button Click
        holder.deleteButton.setOnClickListener(v -> {
            boolean deleted = dbHelper.deleteUser(user.getId());
            if (deleted) {
                userList.remove(position);
                notifyItemRemoved(position);
                notifyItemRangeChanged(position, userList.size());
                Toast.makeText(context, "User deleted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(context, "Delete failed", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return userList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView nameText, emailText;
        EditText editFirstName, editLastName, editEmail;
        Button editButton, deleteButton, updateButton, cancelButton;
        LinearLayout editLayout;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            nameText = itemView.findViewById(R.id.nameText);
            emailText = itemView.findViewById(R.id.emailText);
            editButton = itemView.findViewById(R.id.editButton);
            deleteButton = itemView.findViewById(R.id.deleteButton);
            editLayout = itemView.findViewById(R.id.editLayout);
            editFirstName = itemView.findViewById(R.id.editFirstName);
            editLastName = itemView.findViewById(R.id.editLastName);
            editEmail = itemView.findViewById(R.id.editEmail);
            updateButton = itemView.findViewById(R.id.updateButton);
            cancelButton = itemView.findViewById(R.id.cancelButton);
        }
    }
}
